package com.example.demo.service;

import com.example.demo.bean.YuZhi;

import java.util.List;
import java.util.Map;

public interface YuZhiServive {
    List<YuZhi> getList();
}
